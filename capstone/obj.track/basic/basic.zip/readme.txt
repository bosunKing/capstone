express basic
cd basic
npm i
copy app.js & public
node app.js
run web-browser
open url(localhost:3000)